resource "aws_instance" "web" {
  ami           = "ami-0601422bf6afa8ac3"
  instance_type = "t3.micro"
  subnet_id     = "subnet-0eff7cb4ba3a21b0e"
  vpc_security_group_ids = ["sg-0c776f75bab5028e7"]
  #iam_instance_profile = aws_iam_instance_profile.ec2_ssm_profile.name
  iam_instance_profile = "AdminInstanceProfile"
  user_data = <<-EOF
    #!/bin/bash
    # your user-data script here
    yum update -y
    amazon-linux-extras install nginx1 -y
    systemctl start nginx
  EOF

  tags = { Name = "web-instance" }
}
